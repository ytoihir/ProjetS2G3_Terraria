package modele.map;

public class CSVReaderException extends Exception {
	private String valeur;
	
	public CSVReaderException(String valeur) {
		this.valeur = valeur;
	}
	public String getMessage() {
		if (this.valeur.equals("Ligne")) return "Certaines lignes du CSV ne font pas la même taille";
		else if (this.valeur.equals("Valeur inexistante")) return "Une valeur n'est pas pris en compte dans le découpage des tuiles";
		else return "Valeur ne pouvant être convertie en int " + this.valeur;
	}
}
