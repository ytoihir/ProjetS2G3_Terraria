package modele.inventaire.arme;

import java.util.ArrayList;

import modele.inventaire.ressource.Fer;

public class Epée extends Arme {

	public Epée() {
		super("epee", 1, "/img/inventaire/epee.png", 3);

	}

}
