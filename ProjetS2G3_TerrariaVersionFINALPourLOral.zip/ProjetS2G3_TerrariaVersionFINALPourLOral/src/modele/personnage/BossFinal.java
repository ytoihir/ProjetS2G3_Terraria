package modele.personnage;

public class BossFinal extends Ennemi {

	public BossFinal(int id, String nom, String desc, int PV) {
		super(05, nom, "C'est le maître de ce monde. Et il ne reculera devant rien pour vous éliminer ! Il n'est pas adulé par tous les robots pour rien...", 20);
	}

}