package modele.personnage;

public class Ennemi extends Personnage {

	/*Constructeur d'ennemi*/
	public Ennemi(int id, String nom, String desc, int PV) {
		super(id, nom, desc, PV);
		
	}

}