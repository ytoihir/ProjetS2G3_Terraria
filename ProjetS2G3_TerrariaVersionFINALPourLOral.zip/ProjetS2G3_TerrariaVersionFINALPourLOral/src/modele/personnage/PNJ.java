package modele.personnage;

public class PNJ extends Personnage{

	public PNJ(int id, String nom, String desc) {
		super(id, nom, desc);
		
	}
}