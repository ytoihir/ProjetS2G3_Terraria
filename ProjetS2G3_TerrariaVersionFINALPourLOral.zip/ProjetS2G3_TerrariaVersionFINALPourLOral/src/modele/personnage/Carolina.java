package modele.personnage;

public class Carolina extends Personnage {

	public Carolina() {
		super(01, "Carolina", "Carolina est une jeune fille de 11 ans qui doit retourner dans son monde. Malgré son apparence d'enfant, elle peut se montrer redoutable.", 40);
	}
	
}