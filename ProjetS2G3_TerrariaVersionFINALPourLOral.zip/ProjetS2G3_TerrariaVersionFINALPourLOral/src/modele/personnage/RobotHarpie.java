package modele.personnage;

public class RobotHarpie extends Ennemi {

	public RobotHarpie() {
		super(03, "Robot-Harpie", "C'est une harpie robot... À quoi vous attendiez-vous ?", 5);
	}
	
	public boolean detectionPersoDroite(Personnage carolina) {
		return (carolina.getX() == this.getX()+1 &&  carolina.getY() == this.getY()) ;
			
	}
	
	public boolean detectionPersoGauche(Personnage carolina) {
		if (carolina.getX() == this.getX()-1 && carolina.getY() == this.getY()) {
			return true;
		}
		else return false;
	}
	
	public boolean detectionPersoBas(Personnage carolina) {
		if ( carolina.getY() == this.getY()+1 && ( this.getX() >= carolina.getX()-1  && this.getX() <=carolina.getX()+1 ) ) {
			return true;
		}
		else return false;
	}
	
	public boolean detectionPersoHaut(Personnage carolina) {
		if (carolina.getY() == this.getY()-1 && ( this.getX() >= carolina.getX()-1  && this.getX() <=carolina.getX()+1 )) {
			return true;
		}
		else return false;
	}
	
	/*Si le personnage est détecté par l'ennemi*/
	public boolean possibiliteAttaque(Personnage carolina) {
		if (carolina.getX() == this.getX() && carolina.getY() == this.getY()) {
			return true;
		}
		else return false;
	}
	
	public void deplacementRobotHarpie(Personnage carolina) {
		if (this.detectionPersoBas(carolina)) {
			this.deplacerPerso(0,1);
		}
		if (this.detectionPersoDroite(carolina)) {
			this.deplacerPerso(1,0);
		}
		if (this.detectionPersoGauche(carolina)) {
			this.deplacerPerso(-1, 0);
		}
		if (this.detectionPersoHaut(carolina)) {
			this.deplacerPerso(0, -1);
		}
		if (this.possibiliteAttaque(carolina)) {
			this.attaque(carolina);
		}
	}

}