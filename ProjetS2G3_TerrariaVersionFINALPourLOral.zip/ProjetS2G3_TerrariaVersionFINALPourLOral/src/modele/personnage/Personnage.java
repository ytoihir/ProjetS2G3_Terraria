package modele.personnage;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
public class Personnage {

	private String nom;
	private String desc;
	private int id;
	private int CoupsTotalAvantDeMourir;
	private IntegerProperty xProperty;
	private IntegerProperty yProperty;
	
	/*Constructeur de personnage ayant des PV*/
	public Personnage(int id, String nom, String description, int PV) {
		this.id = id;
		this.nom = nom;
		this.desc = description;
		this.CoupsTotalAvantDeMourir = PV;
		this.xProperty = new SimpleIntegerProperty(9);
		this.yProperty = new SimpleIntegerProperty(0);
	}
	
	/*Constructeur de personnage*/
	public Personnage(int id, String nom, String desc) {
		this.id = id;
		this.nom = nom;
		this.desc = desc;
		this.xProperty = new SimpleIntegerProperty(9);
		this.yProperty = new SimpleIntegerProperty(0);
	}
	
	public IntegerProperty xProperty() {
		return this.xProperty;
	}
	
	public IntegerProperty yProperty() {
		return this.yProperty;
	}
	
	/*Gestion des déplacements du personnage*/
	public void deplacerPerso(int x, int y) {
		this.xProperty.set(this.xProperty.get() + x);
		this.yProperty.set(this.yProperty.get() + y);
	}
	
	public int getX() {
		return this.xProperty.get();
	}
	
	public int getY() {
		return this.yProperty.get();
	}
	
	/*Méthode pour attaque un autre personnage (ennemi)*/
	public void attaque(Personnage p) {
		p.perteVie(1);
	}
	
	public void perteVie(int attaque) {
		this.CoupsTotalAvantDeMourir -= attaque;
	}

	public void gainVie(int gain) {
		this.CoupsTotalAvantDeMourir += gain;
	}

	public int getPV() {
		return this.CoupsTotalAvantDeMourir;
	}
	
	public boolean mort() {
		return this.CoupsTotalAvantDeMourir <= 0;
	}
	
	public void setPV(int gainOuPerte) {
		this.CoupsTotalAvantDeMourir += gainOuPerte;
	}
	
	public void setXProperty(int x) {
		this.xProperty.set(x);
	}
	
	public void setYProperty(int y) {
		this.yProperty.set(y);
	}
	
}