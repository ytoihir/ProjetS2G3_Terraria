package controleur;

import java.beans.*;
import java.io.*;

import application.Constantes;
import application.Main;

import java.net.URL;
import java.util.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.util.Duration;
import modele.inventaire.Inventaire;
import modele.inventaire.Objet;
import modele.inventaire.arme.Epée;
import modele.inventaire.outil.Pioche;
import modele.inventaire.ressource.Fer;
import modele.map.CSVReader;
import modele.map.CSVReaderException;
import modele.map.Tuile;
import modele.personnage.Carolina;
import modele.personnage.Ennemi;
import modele.personnage.Personnage;
import modele.personnage.RobotHarpie;
import javafx.event.EventHandler;

public class ControleurMap implements Initializable ,  ListChangeListener<Objet> {

	@FXML
	private Pane pane;

	@FXML
	private Pane affichageMapCiel;

	@FXML
	private Pane affichageMapSol;

	@FXML
	private ImageView perso;

	private int imageCliquée;

	@FXML
	private ImageView decor;

	private Personnage p;

	private CSVReader csvSol;

	private Timeline gameLoop;

	private int temps;

	private RobotHarpie e;

	private boolean tenirOuReposer = false, clic = false, aUnePioche = false;
	private ImageView imgView;
	private ArrayList <ImageView> casesInventaire;	 

	private Inventaire ivt;

	@FXML
	private ImageView case1 ;
	@FXML
	private ImageView case2 ;
	@FXML
	private ImageView case3 ;
	@FXML
	private ImageView case4 ;
	@FXML
	private ImageView case5 ;
	@FXML
	private ImageView case6 ;

	@FXML
	private ImageView imageEtabli;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Pane paneEtabli;

	private PaneEtabli constructeurPaneEtabli;

	private boolean tientUnObjet = false;

	@FXML
	private ImageView imgRobotHarpie;

	/*Créateur de la map*/
	public void creationMap() throws CSVReaderException {
		csvSol = new CSVReader();
		csvSol.tuileListe(Constantes.fichierCSV);
		ObservableList<Tuile> mapSol = csvSol.getListeTuile();
		for (int j = 0; j < mapSol.size() ; j++) {
			if (mapSol.get(j).getId().equals("0")) {
				mapSol.get(j).setCollision(true);
				ImageView blocSol0 = new ImageView();
				blocSol0.setImage(Constantes.sol0);
				blocSol0.setX(csvSol.getListeTuile().get(j).getPosX()*Constantes.taille_pixel);
				blocSol0.setY(csvSol.getListeTuile().get(j).getPosY()*Constantes.taille_pixel);
				affichageMapSol.getChildren().add(blocSol0);
			}
			if (mapSol.get(j).getId().equals("1")) {
				mapSol.get(j).setCollision(true);
				ImageView blocSol1 = new ImageView();
				blocSol1.setImage(Constantes.sol1);
				blocSol1.setX(csvSol.getListeTuile().get(j).getPosX()*Constantes.taille_pixel);
				blocSol1.setY(csvSol.getListeTuile().get(j).getPosY()*Constantes.taille_pixel);
				affichageMapSol.getChildren().add(blocSol1);
			}
			if (mapSol.get(j).getId().equals("-1")) {
				ImageView blocTransparent = new ImageView();
				blocTransparent.setImage(Constantes.tuileTransparente);
				blocTransparent.setX(csvSol.getListeTuile().get(j).getPosX()*Constantes.taille_pixel);
				blocTransparent.setY(csvSol.getListeTuile().get(j).getPosY()*Constantes.taille_pixel);
				affichageMapSol.getChildren().add(blocTransparent);
			}
		}
	}


	/*Créateur du personnage*/
	public void creationPerso() {
		p = new Carolina();
		perso = new ImageView("file:src/ImgPersonnage/filleidle.png");
		perso.translateXProperty().bind(p.xProperty().multiply(Constantes.taille_pixel));
		perso.translateYProperty().bind(p.yProperty().multiply(Constantes.taille_pixel));
		perso.setFocusTraversable(true);
		perso.setFitHeight(Constantes.taille_pixel);
		perso.setFitWidth(Constantes.taille_pixel);
		pane.getChildren().add(perso);
		pane.setMouseTransparent(true);
		pane.setFocusTraversable(true);
		pane.setOnKeyPressed(e -> enMouvement(e));
		pane.setOnKeyReleased(e -> enArret(e));
	}

	/*Méthode qui gère l'arret du personnage*/
	@FXML
	void enArret(KeyEvent event) {

		this.p.deplacerPerso(0, 0);

		KeyCode toucheLibere = event.getCode();

		if (retournerNomOutilCliqué(imageCliquée) == "etabli") System.out.println("On ne peut pas prendre l'etabli en main");

		else  {
			switch (toucheLibere) {

			case D:

				if(tientUnObjet) perso.setImage(new Image("/img/perso/perso" + "_" + retournerNomOutilCliqué(imageCliquée) + ".png" ));
				else perso.setImage(Constantes.personnageRegardantADroite);
				break;

			case Q:

				if(tientUnObjet) perso.setImage(new Image("/img/perso/persoGauche" + "_" + retournerNomOutilCliqué(imageCliquée) + ".png" ));
				else perso.setImage(Constantes.personnageRegardantAGauche);
				break;

			}

		}



	}


	/*Méthode qui déplace le personnage sur la vue et le modèle*/
	@FXML

	void enMouvement(KeyEvent event) {

		KeyCode key = event.getCode();

		switch (key) {

		case Z:
			perso.setImage(Constantes.personnageVuDeDos);
			deplacement(0, -1);
			break;

		case S:

			perso.setImage(Constantes.personnageIdle);
			deplacement(0, 1);
			break;

		case D:

			/* animation */

			perso.setImage(Constantes.personnageRegardantADroite);
			if(tientUnObjet && retournerNomOutilCliqué(imageCliquée) != "etabli") perso.setImage(new Image("/img/perso/perso" + "_" + retournerNomOutilCliqué(imageCliquée) + ".gif" ));
			else perso.setImage(Constantes.personnageCourantADroite);

			/* si pas de collision*/
			if (this.p.xProperty().get() == 19 ) {
				// System.out.println("On ne peut pas aller plus à droite !");
			}
			else {
				deplacement(1, 0);
			}
			break;

		case Q:

			perso.setImage(Constantes.personnageRegardantAGauche);

			if(tientUnObjet && retournerNomOutilCliqué(imageCliquée) != "etabli" ) perso.setImage(new Image("/img/perso/persoGauche" + "_" + retournerNomOutilCliqué(imageCliquée) + ".gif" ));
			else perso.setImage(Constantes.personnageCourantAGauche);

			if (this.p.xProperty().get() == 0) {
				// System.out.println("On ne peut pas aller plus à gauche !");
			}

			else {
				deplacement(-1, 0);
			}
			break;

		}

	}

	/*Gestion des déplacements du personnage*/
	private void deplacement(int x, int y) {
		if (csvSol.collision(x+this.p.xProperty().get(), y+this.p.yProperty().get())) {
			//			System.out.println("collision je ne peux pas y aller!");
		}
		else {
			p.deplacerPerso(x, y);
		}
	}

	/*Gestion des déplacements de l'ennemi*/
	private void deplacementEnnemi(int x, int y) {
		if (csvSol.collision(x+this.p.xProperty().get(), y+this.p.yProperty().get())) {	
		}
		else {
			e.deplacerPerso(x, y);
		}
	}

	/*Méthode qui provoque la gravité du personnage*/
	private void initGravite(int x) {
		if (!csvSol.collision(this.p.xProperty().get()+x, this.p.yProperty().get()+1)) {
			p.deplacerPerso(x, 1);
		}
	}

	/*Création de la gameloop du jeu*/
	private void initAnimation() {
		gameLoop = new Timeline();
		temps=0;
		gameLoop.setCycleCount(Timeline.INDEFINITE);
		int x = 0, y = 0;
		KeyFrame kf = new KeyFrame(
				Duration.seconds(0.1),
				(ev ->{
					e.deplacementRobotHarpie(p);
					if (p.getX() == e.getX() && p.getY() == e.getY()) {
						p.attaque(e);
					}
					if (e.mort()) {
						System.out.println("Vous avez gagné !");
						System.exit(0);
					}
					if (p.mort()) {
						System.out.println("Vous êtes mort !");
						System.exit(0);
					}
					initGravite(x);
					//					System.out.println("PV de Carolina : " + p.getPV());
					//					System.out.println("PV de Robot-Harpie : " + e.getPV());
				}));
		gameLoop.getKeyFrames().add(kf);
	}

	/*Méthode de gestion des clics de souris sur la map*/
	public void interactionClic() {

		Main.getPrimaryStage().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent e) {
				int x = (int) e.getX()/Constantes.taille_pixel;
				int y = (int) e.getY()/Constantes.taille_pixel;
				switch (e.getButton()) {
				case PRIMARY:

					if (y*Constantes.taille_pixel>=0 && y*Constantes.taille_pixel<=55) {
						if ((x*Constantes.taille_pixel>=0 && x*Constantes.taille_pixel<=48)) {
//							System.out.println("case1");
							prendreObjet(0);
							imageCliquée=0;
						}

						else if((x*Constantes.taille_pixel>48 && x*Constantes.taille_pixel<=96)) {
//							System.out.println("case2");
							prendreObjet(1);
							imageCliquée=1;
						}

						else if((x*Constantes.taille_pixel>96 && x*Constantes.taille_pixel<=134)) {
//							System.out.println("case3");
							prendreObjet(2);
							imageCliquée=2;
						}

						else if((x*Constantes.taille_pixel>134 && x*Constantes.taille_pixel<=192)) {
//							System.out.println("case4");
							prendreObjet(3);
							imageCliquée=3;
						}

						else if((x*Constantes.taille_pixel>192 && x*Constantes.taille_pixel<=240)) {
//							System.out.println("case5");
							prendreObjet(4);
							imageCliquée=4;
						}

						else if((x*Constantes.taille_pixel>240 && x*Constantes.taille_pixel<=288)) {
//							System.out.println("case6");
							prendreObjet(5);
							imageCliquée=5;
						}

					}

					if (clic==true && x*Constantes.taille_pixel>160 && x*Constantes.taille_pixel<=192) {
						if (y*Constantes.taille_pixel>=128 && y*Constantes.taille_pixel<=129) {
							//System.out.println("boutonInventaire1");
							constructeurPaneEtabli.setIdObjetFabriquable(0);
							constructeurPaneEtabli.fabriquerObjetVue(constructeurPaneEtabli.getIdObjetFabriquable(), ivt);

						}
						else if (y*Constantes.taille_pixel>=160 && y*Constantes.taille_pixel<=192) {
							constructeurPaneEtabli.setIdObjetFabriquable(1);
							constructeurPaneEtabli.fabriquerObjetVue(constructeurPaneEtabli.getIdObjetFabriquable(), ivt);
							//System.out.println("boutonInventaire2");
						}
						//System.out.println(ivt.getListeObjets());
					}

					else {
//						System.out.println("j'ai cliqué sur une tuile à x = " + x +" et y = "+ y);
						if (!aUnePioche) {
							System.out.println("Je n'ai pas de pioche !");
						}
						else {
							for (int i = 0; i < csvSol.getListeTuile().size(); i++) {
								if (csvSol.getListeTuile().get(i).getPosX() == x && csvSol.getListeTuile().get(i).getPosY() == y && !csvSol.getListeTuile().get(i).getId().equals("-1")) {
									if (x < p.getX()- 1 || x > p.xProperty().get()+ 1 || y < p.yProperty().get()- 1 || y > p.getY() + 1) {
										System.out.println("On ne peut pas poser un bloc");
									}
									else {
										if(!(ivt.ivtRemplit())) {
											ivt.ajouterObjet(new Fer());	
											csvSol.setTuileVide(x, y);
											csvSol.getListeTuile().get(i).setCollision(false);
											ImageView newTuil = new ImageView(Constantes.tuileTransparente);
											newTuil.setX(x*Constantes.taille_pixel);
											newTuil.setY(y*Constantes.taille_pixel);
											affichageMapSol.getChildren().set(i,newTuil);
										}

									}
									break;
								}
							}
						}
					}
					break;

				case SECONDARY:
//					System.out.println("j'ai cliqué sur une tuile à x = " + x +" et y = "+ y);
					for (int i = 0; i < csvSol.getListeTuile().size(); i++) {
						if (csvSol.getListeTuile().get(i).getPosX() == x && csvSol.getListeTuile().get(i).getPosY() == y && csvSol.getListeTuile().get(i).getId().equals("-1")) {
							if (x < p.getX()- 1 || x > p.xProperty().get()+ 1 || y < p.yProperty().get()- 1 || y > p.getY() + 1 /*|| (x == p.getX() && y == p.getY())*/) {
								System.out.println("On ne peut pas poser un bloc");
							}
							else if (csvSol.getTuile(csvSol.calculerIndice(x, y+1)).getId().equals("-1") || (x == p.getX() && y == p.getY())) {
//								System.out.println("j'ai cliqué sur une tuile à x = " + x + " et y = "+ y);
//								System.out.println("La tuile à x = " + x + " et y = " + (y-1) + " est vide -> " + csvSol.getTuile(csvSol.calculerIndice(x, y-1)).getCollision());
							}
							else {
								for(int z = 0; z < ivt.getListeObjets().size(); z++) {
									if(ivt.getListeObjets().get(z).getNom().equals("fer")) {
										ivt.enleverObjet(ivt.getListeObjets().get(z));
										casesInventaire.get(z).setImage(null);
										csvSol.setNouvelleTuile("1", x, y);
										csvSol.getListeTuile().get(i).setCollision(true);
										ImageView newTuil = new ImageView(Constantes.sol1);
										newTuil.setX(x*Constantes.taille_pixel);
										newTuil.setY(y*Constantes.taille_pixel);
										affichageMapSol.getChildren().set(i,newTuil);
									}
								}
								
								if(ivt.retournerNbObjet("fer") == 0) System.out.println("Pas de fer dans l'inventaire : on ne peut pas en poser");
								
							}
							break;
						}
					}
					break;
				}
			}

		});


	}

	/*Créateur d'ennemi*/
	public void creationEnnemi() {
		e = new RobotHarpie();
		imgRobotHarpie = new ImageView(Constantes.robotHarpie);
		imgRobotHarpie.xProperty().bind(e.xProperty().multiply(Constantes.taille_pixel));
		imgRobotHarpie.yProperty().bind(e.yProperty().multiply(Constantes.taille_pixel));
		imgRobotHarpie.setFocusTraversable(true);
		e.setXProperty(19);
		e.setYProperty(9);
		pane.getChildren().add(imgRobotHarpie);
		pane.setMouseTransparent(true);
		pane.setFocusTraversable(true);

	}

	/*Gestion de l'affichage de l'établi*/
	public void afficheListeObjets() {

		if (clic) {

			if (constructeurPaneEtabli.getAlerte()!=null) {
				constructeurPaneEtabli.setAlerte("");
			}

			paneEtabli.setVisible(false);
			clic=false;

		}

		else {

			paneEtabli.setVisible(true);
			clic = true;

		}

	}

	// retourne le nom de l'outil cliqué 
	public String retournerNomOutilCliqué(int indice){

		String idObj;

		idObj=casesInventaire.get(indice).getId();

		for(int y = 0; y < this.ivt.getListeObjets().size(); y++) {
			if (ivt.getListeObjets().get(y).getId()==idObj) {
				return this.ivt.getListeObjets().get(y).getNom();
			}
		}

		return null;

	}


	// methode qui change l'image du joueur selon l'outil cliqué dans l'inventaire
	public void prendreObjet(int indice) {
		Image img = null, imgB;

//		System.out.println(retournerNomOutilCliqué(indice));

		if(retournerNomOutilCliqué(indice) == null) System.out.println("case vide");

		else if(retournerNomOutilCliqué(indice) != null && retournerNomOutilCliqué(indice)!="etabli") {

			if(perso.getImage() == Constantes.personnageRegardantADroite) 

				img = new Image("/img/perso/perso" + "_" + retournerNomOutilCliqué(indice) + ".png");
				imgB = new Image("/img/perso/filledroitidle.png");

			if(perso.getImage() == Constantes.personnageRegardantAGauche)
				img = new Image("/img/perso/perso" + "Gauche_" + retournerNomOutilCliqué(indice) + ".png");
				imgB = Constantes.personnageRegardantAGauche;



			if(!tenirOuReposer ) { 

				perso.setImage(img);
				tenirOuReposer = true;
				tientUnObjet = true;
				if(retournerNomOutilCliqué(indice).equals("pioche")) aUnePioche = true;


			}

			else if(tenirOuReposer) {

				perso.setImage(imgB);
				tenirOuReposer = false;
				if(retournerNomOutilCliqué(indice).equals("pioche") || retournerNomOutilCliqué(indice).equals("arc") || retournerNomOutilCliqué(indice).equals("epee")) aUnePioche = false;

			}



		}

		else if (retournerNomOutilCliqué(indice).equals("etabli")) {
			afficheListeObjets();
		}
		
		
	}

	
	public ArrayList<ImageView> getListeInventaire (){
		return this.casesInventaire;
	}

	public Inventaire getIvt () {
		return this.ivt;
	}

	public void ajouterImageObjet() {
		for(int i = 0; i < casesInventaire.size(); i++){
			if(casesInventaire.get(i).getImage() == null) {
				casesInventaire.get(i).setImage( new Image( ivt.getDernierObjet().getValPNG() ) );
				casesInventaire.get(i).setId(ivt.getDernierObjet().getId());
				break;
			}
		
			else if( (ivt.getDernierObjet().getNom().equals("arc") || ivt.getDernierObjet().getNom().equals("epee"))) {
				for(int a = 0; a < ivt.getListeObjets().size(); a++) {
					//if(ivt.getListeObjets().get(a).getNom().equals("fer")) {
					if(ivt.getListeObjets().get(a).getId().equals(casesInventaire.get(i).getId())) {
						casesInventaire.get(ivt.retourneIndice1erFer()).setImage(new Image( ivt.getDernierObjet().getValPNG()));
						casesInventaire.get(ivt.retourneIndice1erFer()).setId(ivt.getDernierObjet().getId());
						break;
					} 
					
				}
				
			}
			
		}
	} 

	/*Gestion du listener présent sur l'inventaire*/
	@Override
	public void onChanged(ListChangeListener.Change<? extends Objet> c) {

		while (c.next()){
			if (  c.wasAdded()){
				//System.out.println("ajout...");
				ajouterImageObjet();
			}

			else if (c.wasRemoved()){
				//System.out.println("suppression...");
			}

		}

	}

	public Pane getPaneEtabli() {
		return paneEtabli;
	}

	public ArrayList<ImageView> getListeImgView() {
		return this.casesInventaire;

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println(		
		"Z -> Aller en haut\n"
		+ "Q -> Aller à gauche\n"
		+ "S -> Aller en bas\n"
		+ "D -> Aller à droite\n"
		+ "Clic gauche (sur un bloc) -> Miner\n"
		+ "Clic droit (sur un bloc) -> Poser un bloc (si présent dans l'inventaire)\n"
		+ "Clic gauche (sur l'inventaire) -> Fait apparaître l'établi ou prend en main un objet\n"
		+ "Clic gauche (sur les boutons de l'établi) -> Permet de crafter l'objet souhaité\n"
		+ "Attention, l'inventaire ne fonctionne pas très bien. Si vous voulez crafter, miner des ressources afin de remplir entièrement l'inventaire.\n"
		+ "Ensuite, crafter d'abord une épée puis un arc.");
		try {
			this.creationMap();
		} catch (CSVReaderException e) {
			e.printStackTrace();
			System.exit(0);
		}
		this.creationPerso();
		this.initAnimation();
		this.gameLoop.play();
		this.creationEnnemi();

		//this.creationEnnemi();	
		//		this.e = new RobotHarpie(null);
		//		 Main.getPrimaryStage().getScene().setOnKeyPressed(e -> {
		//             ((Object) keyList).addKeyCode(e.getCode());
		//             if (e.getCode() == KeyCode.I)
		//                 c.getInventoryContainer().setVisible(c.getInventoryContainer().isVisible() ? false : true);
		//             e.consume();
		//         });

		this.ivt = new Inventaire();

		this.ivt.getListeObjets().addListener(this);		

		this.paneEtabli.setVisible(false);

		casesInventaire  = new ArrayList<>();
		casesInventaire.add(case1);
		casesInventaire.add(case2);
		casesInventaire.add(case3);
		casesInventaire.add(case4);
		casesInventaire.add(case5);
		casesInventaire.add(case6);

		ivt.ajouterObjet(new Pioche());
		
		constructeurPaneEtabli = new PaneEtabli(this);

		this.interactionClic();

	}



}