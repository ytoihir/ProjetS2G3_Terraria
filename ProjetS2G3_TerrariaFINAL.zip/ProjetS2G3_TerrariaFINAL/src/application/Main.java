package application;
	
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import controleur.ControleurMap;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.TilePane;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	private static Stage primaryStage;
	
	private void setPrimaryStage(Stage stage) {
        Main.primaryStage = stage;
    }
	
	static public Stage getPrimaryStage() {
        return Main.primaryStage;
    }
	
	@Override
	public void start(Stage primaryStage) {
		
		try {
			setPrimaryStage(primaryStage);
			FXMLLoader loader = new FXMLLoader();
			URL url = new File("src/vue/vueMap.fxml").toURI().toURL();
			loader.setLocation(url);
			Pane root = new Pane();
			root = loader.load();
			Scene scene = new Scene(root,640,640);
			primaryStage.setScene(scene);
			primaryStage.setTitle("Last Resort");
			primaryStage.setResizable(false);
			primaryStage.show();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
