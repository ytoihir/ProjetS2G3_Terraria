package controleur;

import java.util.ArrayList;

import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import modele.inventaire.Inventaire;
import modele.inventaire.etabli.Etabli;

public class PaneEtabli {
	
	private Text alerte;

	private ControleurMap contInventaire;
	
	private String idObjet;
	
	private Etabli e;
	
	public PaneEtabli(ControleurMap ivt) {
		this.contInventaire = ivt;
		Image etabli = new Image("/img/inventaire/etablieEcran.png");
		ivt.getPaneEtabli().getChildren().add(new ImageView(etabli));
		e=contInventaire.getIvt().initialiserEtabli();
		configurerEtabli(e);
	}
	
	public void fabriquerObjetVue(String id, Inventaire i) {

		this.contInventaire.getIvt().getEtabli().choisirUnObjet(id); 
		ArrayList<String> liste = contInventaire.getIvt().getEtabli().fabriquerObjet(i);

		if(liste==null) {
			alerte = new Text();
			contInventaire.getPaneEtabli().getChildren().add(alerte);
			alerte.setLayoutY(220);
			alerte.setFill(Color.WHITE);
			alerte.setText("Pas les ressources nécessaires!");
		}
		
		else if (liste!=null) {
			String idImageView=null;
			for (int a=0; a<contInventaire.getListeImgView().size(); a++) {
			
				idImageView = contInventaire.getListeImgView().get(a).getId();
				
				for (int b=0; b<liste.size(); b++) {
					if(idImageView==liste.get(b)) {
						contInventaire.getListeImgView().get(a).setImage(null);
					}
				}
				
			}
		
		}
		
	}
	
	public void configurerEtabli(Etabli e) {
			   
		int xObjets = 10;
		int yObjets = 10;
		
		int xBoutons = 90;
		int yBoutons = 10;
		
		int xRessources = 50;
		int yRessources = 10;
		
		int xNbrRessources = 70;
		int yNbrRessources = 10;
		
		for (int i=0; i<e.getListeObjetFabriquable().size(); i++) {
			
			ImageView vueObjet = new ImageView(e.getListeObjetFabriquable().get(i).getValPNG());		
			VBox VBoxObjets = new VBox();
			VBoxObjets.getChildren().add(vueObjet);
			vueObjet.setFitWidth(30);
			vueObjet.setFitHeight(30);
	
			VBoxObjets.setLayoutX(xObjets);
			VBoxObjets.setLayoutY(yObjets+=40);
			
			contInventaire.getPaneEtabli().getChildren().add(VBoxObjets);
			
			// fabriquer un objet lors du click du bouton
			
			Button b = new Button();
			b.setText("F");
			
			idObjet = e.getListeObjetFabriquable().get(i).getId();

			b.setOnAction(evt -> {fabriquerObjetVue(idObjet, contInventaire.getIvt());});
			
			VBox VBoxBoutons = new VBox();

			VBoxBoutons.getChildren().add(b);
			VBoxBoutons.setLayoutX(xBoutons);
			VBoxBoutons.setLayoutY(yBoutons+=40);
			
			contInventaire.getPaneEtabli().getChildren().add(VBoxBoutons);
			
			// afficher les images view des ressources necessaires à avoir pour crafter les objets
			
			ImageView vueRessource = new ImageView(new Image("/img/ressource/map_1.png"));

			VBox VBoxRessources = new VBox();
			VBoxRessources.setLayoutX(xRessources);
			VBoxRessources.setLayoutY(yRessources+=43);
			
			VBoxRessources.getChildren().add(vueRessource);
			vueRessource.setFitWidth(15);
			vueRessource.setFitHeight(15);
			
			contInventaire.getPaneEtabli().getChildren().add(VBoxRessources);
			
			Text t=new Text(e.getListeObjetFabriquable().get(i).getFerNecessaires()+"x");
			VBox affichageNbrRessources = new VBox();
			
			affichageNbrRessources.getChildren().add(t);

			affichageNbrRessources.setLayoutX(xNbrRessources);
			affichageNbrRessources.setLayoutY(yNbrRessources+=43);

			contInventaire.getPaneEtabli().getChildren().add(affichageNbrRessources);

		}
	
	}
	
		public String getIdObjetFabriquable() {
			return this.idObjet;
		}
		
		public Text getAlerte() {
			return this.alerte;
		}
		
		public void setAlerte(String texte) {
			this.alerte.setText(texte);
		}
		
		public void setIdObjetFabriquable(int indice) {
			this.idObjet=e.getListeObjetFabriquable().get(indice).getId();
		}

}