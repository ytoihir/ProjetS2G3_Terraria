package modele.map;

public class CSVReaderException {
	private String valeur;
	
	public CSVReaderException(String valeur) {
		this.valeur = valeur;
	}
	public String getMessage() {
		if (this.valeur == "Ligne") return "Certaines lignes du CSV ne font pas la même taille";
		else if (this.valeur == "Valeur Inexistante") return "Une valeur n'est pas pris en compte dans le découpage des tuiles";
		return "Valeur ne pouvant être convertie en int " + this.valeur;
	}
}
