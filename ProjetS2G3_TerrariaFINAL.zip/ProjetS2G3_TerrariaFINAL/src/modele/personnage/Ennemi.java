package modele.personnage;

public class Ennemi extends Personnage {

	/*Constructeur d'ennemi*/
	public Ennemi(int id, String nom, String desc, int PV) {
		super(id, nom, desc, PV);
		
	}
	
	public boolean detectionPersoDroite(Personnage carolina) {
		return (carolina.getX() == this.getX()+1 &&  carolina.getY() == this.getY()) ;
			
	}
	
	public boolean detectionPersoGauche(Personnage carolina) {
		if (carolina.getX() == this.getX()-1 && carolina.getY() == this.getY()) {
			return true;
		}
		else return false;
	}
	
	public boolean detectionPersoBas(Personnage carolina) {
		if ( carolina.getY() == this.getY()+1 && ( this.getX() >= carolina.getX()-1  && this.getX() <=carolina.getX()+1 ) ) {
			return true;
		}
		else return false;
	}
	
	public boolean detectionPersoHaut(Personnage carolina) {
		if (carolina.getY() == this.getY()-1 && ( this.getX() >= carolina.getX()-1  && this.getX() <=carolina.getX()+1 )) {
			return true;
		}
		else return false;
	}
	
	/*Si le personnage est détecté par l'ennemi*/
	public boolean possibiliteAttaque(Personnage carolina) {
		if (carolina.getX() == this.getX() && carolina.getY() == this.getY()) {
			return true;
		}
		else return false;
	}

}