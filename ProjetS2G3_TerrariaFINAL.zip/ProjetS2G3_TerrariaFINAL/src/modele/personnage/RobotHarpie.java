package modele.personnage;

public class RobotHarpie extends Ennemi {

	public RobotHarpie() {
		super(03, "Robot-Harpie", "C'est une harpie robot... À quoi vous attendiez-vous ?", 5);
	}
	
	

}