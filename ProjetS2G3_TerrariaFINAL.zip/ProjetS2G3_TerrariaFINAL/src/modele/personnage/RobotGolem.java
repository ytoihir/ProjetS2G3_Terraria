package modele.personnage;

public class RobotGolem extends Ennemi {

	public RobotGolem(int id, String nom, String desc, int PV) {
		super(04, "Robot-Golem", "C'est un golem robot... À quoi vous attendiez-vous ?", 10);
	}
	
}