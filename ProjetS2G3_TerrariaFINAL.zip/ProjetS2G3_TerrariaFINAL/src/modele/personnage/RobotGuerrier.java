package modele.personnage;

public class RobotGuerrier extends Ennemi {

	public RobotGuerrier(int id, String nom, String desc, int PV) {
		super(02, "Robot-Guerrier", "C'est un guérrier robot... À quoi vous attendiez-vous ?", 2);
	}

}