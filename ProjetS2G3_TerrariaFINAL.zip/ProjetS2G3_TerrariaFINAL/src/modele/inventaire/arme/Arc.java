package modele.inventaire.arme;

import java.util.ArrayList;

import modele.inventaire.ressource.Fer;

public class Arc extends Arme {

	
	public Arc() {
		super("arc", 1, "/img/inventaire/arc.png", 2);
	}

}
