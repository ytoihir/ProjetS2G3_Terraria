package modele.inventaire.outil;

import modele.inventaire.Objet;

public class Pioche extends Objet{

	public Pioche() {
		super("pioche", "/img/inventaire/pioche.png");
		
	}

	
}
