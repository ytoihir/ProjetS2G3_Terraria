package modele.inventaire.ressource;

import modele.inventaire.Objet;

public class Fer extends Objet {

	private String valeurPNG;
	
	public Fer (){
		
		super("fer", "/img/ressource/map_1.png");
		
	}


	
}
